import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, Check, ChevronLeft, ChevronRight, Crown, Edit3, Eye, EyeOff, Heart, KeyRound, Plus, Search, ShieldCheck, Sparkles, Trash2, UsersRound, X } from "lucide-react";
import { API_BASE, BRAND } from "./config/brand";
import { awardsApi } from "./services/awards";
import { ApiError } from "./services/client";
import type { Category, CreateUser, Gender, Interest, Role, User } from "./types";
import { session } from "./utils/session";
import { openPhotoChangeWhatsApp, openResetWhatsApp } from "./utils/whatsapp";
import { DashboardHeader, Footer, Header } from "./components/Chrome";
import { Empty, ErrorState, Loading } from "./components/States";
import { PhotoUpload } from "./components/PhotoUpload";
import { FlyerCard } from "./components/FlyerCard";

function CategoryManagementContent() { const [items, setItems] = useState<Category[]>([]); const [query, setQuery] = useState(""); const [name, setName] = useState(""); const [description, setDescription] = useState(""); const [editingId, setEditingId] = useState<string | null>(null); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [success, setSuccess] = useState(""); const load = () => { awardsApi.categories().then(data => setItems(data.categories)).catch(e => setError(e instanceof Error ? e.message : "Unable to load categories.")); }; useEffect(load, []); const reset = () => { setEditingId(null); setName(""); setDescription(""); }; const submit = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); if (!name.trim()) return; setSaving(true); setError(""); setSuccess(""); const wasEditing = Boolean(editingId); try { if (editingId) await awardsApi.updateCategory(editingId, { name: name.trim(), description: description.trim() }); else await awardsApi.createCategory({ name: name.trim(), description: description.trim() }); reset(); setSuccess(wasEditing ? "Category updated successfully." : "Category created successfully."); load(); } catch (e) { setError(e instanceof Error ? e.message : "Unable to save category."); } finally { setSaving(false); } }; const edit = (category: Category) => { setEditingId(category.id); setName(category.name); setDescription(category.description ?? ""); }; const remove = async (category: Category) => { if (!confirm(`Delete the ${category.name} category?`)) return; setError(""); setSuccess(""); try { await awardsApi.deleteCategories([category.id]); setSuccess("Category deleted successfully."); if (editingId === category.id) reset(); load(); } catch (e) { setError(e instanceof Error ? e.message : "Unable to delete category."); } }; const visible = items.filter(category => `${category.name} ${category.description ?? ""}`.toLowerCase().includes(query.toLowerCase())); return <section className="panel category-management"><div className="panel-title"><div><p className="eyebrow">CATEGORY NAVIGATION</p><h2>Manage categories</h2></div><Plus className="gold-icon"/></div>{error && <Notice text={error}/>} {success && <Notice text={success} kind="success"/>}<form className="category-form" onSubmit={submit}><div className="category-fields"><Field label="Category name" value={name} onChange={setName}/><label>Description<textarea value={description} onChange={event => setDescription(event.target.value)} rows={2} placeholder="What does this category celebrate?"/></label></div><div className="category-form-actions"><button className="button" disabled={!name.trim() || saving}>{saving ? "Saving…" : editingId ? "Update category" : "Create category"}</button>{editingId && <button type="button" className="text-btn" onClick={reset}><X size={16}/> Cancel</button>}</div></form><div className="category-filter search"><Search size={17}/><input placeholder="Search categories" value={query} onChange={event => setQuery(event.target.value)}/></div>{visible.length ? <div className="managed-category-list">{visible.map(category => <article className="managed-category" key={category.id}><div><h3>{category.name}</h3><p>{category.description || "No description added."}</p></div><div className="category-actions"><button className="text-btn" type="button" onClick={() => edit(category)}><Edit3 size={15}/> Edit</button><button className="text-btn danger" type="button" onClick={() => void remove(category)}><Trash2 size={15}/> Delete</button></div></article>)}</div> : <Empty label="No categories match your search."/>}</section>; }

function AdminResetImageCount({ user, onUpdated }: { user: User; onUpdated: (user: User) => void }) { const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const reset = async () => { if (!confirm(`Reset ${user.firstName} ${user.lastName}'s image change count?`)) return; setSaving(true); setError(""); try { onUpdated(await awardsApi.resetProfileChangeCount(user.id)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to reset image changes."); } finally { setSaving(false); } }; return <div className="reset-count-control">{error && <Notice text={error}/>}<button type="button" className="button mini reset-count-button" disabled={saving || user.profileChangeCount === 0} onClick={() => void reset()}>{saving ? "Resetting…" : "Reset image change count"}</button></div>; }

const route = () => location.hash.slice(1) || "/";
const prettyRole = (role: Role) => role.replace(/_/g, " ").toLowerCase();
const formatName = (value: string) => value.replace(/\s+/g, " ").trim().split(" ").filter(Boolean).map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()).join(" ");
const uploadProfilePhotoWithProgress = async (id: string, file: File, onProgress: (progress: number) => void): Promise<User> => {
  const form = new FormData();
  form.append("profileImage", file);
  return await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PATCH", `${API_BASE}/users/${id}/profile-image`);
    xhr.upload.onprogress = (event) => {
      if (!event.lengthComputable) return;
      onProgress(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onload = () => {
      try {
        const payload = JSON.parse(xhr.responseText) as { success?: boolean; data?: User; message?: string };
        if (xhr.status >= 200 && xhr.status < 300 && payload.success && payload.data) {
          resolve(payload.data);
          return;
        }
        reject(new ApiError(payload?.message ?? "Unable to upload photo."));
      } catch {
        reject(new ApiError("Unable to upload photo."));
      }
    };
    xhr.onerror = () => reject(new ApiError("Unable to upload photo."));
    xhr.send(form);
  });
};
function useHash() { const [path, setPath] = useState(route()); useEffect(() => { const update = () => setPath(route()); addEventListener("hashchange", update); return () => removeEventListener("hashchange", update); }, []); useEffect(() => { const hideNotice = (notice: Element) => { notice.scrollIntoView({ behavior: "smooth", block: "center" }); window.setTimeout(() => { (notice as HTMLElement).style.display = "none"; }, 4500); }; const observer = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => { if (node instanceof HTMLElement && node.classList.contains("notice")) hideNotice(node); }))); observer.observe(document.body, { childList: true, subtree: true }); return () => observer.disconnect(); }, []); return path; }
function Notice({ text, kind = "error" }: { text: string; kind?: "error" | "success" }) { const ref = useRef<HTMLDivElement>(null); const [visible, setVisible] = useState(Boolean(text)); useEffect(() => { setVisible(Boolean(text)); if (!text) return; ref.current?.scrollIntoView({ behavior: "smooth", block: "center" }); ref.current?.focus(); const timer = window.setTimeout(() => setVisible(false), 4500); return () => window.clearTimeout(timer); }, [text]); if (!visible || !text) return null; return <div className={`notice${kind === "success" ? " success" : ""}`} role={kind === "success" ? "status" : "alert"} tabIndex={-1} ref={ref}>{text}</div>; }

//for image background
function Home() { const [categories, setCategories] = useState<Category[]>([]); useEffect(() => { awardsApi.categories().then(x => setCategories(x.categories.slice(0, 3))).catch(() => {}); }, []); return <><Header/><main><section className="hero"><div className="hero-video"><img src={BRAND.backgroundPath} alt="" fetchPriority="high" decoding="async" /></div><div className="hero-copy"><p className="eyebrow">ODOBEN'S NIGHT OF DISTINCTION</p><h1>Own your <i>moment.</i></h1><p>{BRAND.slogan} Step forward, share your story and let the community celebrate what you bring to Odoben.</p><div className="actions"><a className="button" href="#/register">Become a nominee <ArrowRight size={17}/></a><a className="link" href="#/categories">Explore categories</a></div></div><div className="hero-mark"><Sparkles/><span>YES<br/>2026</span></div></section><section className="section" id="how-it-works"><p className="eyebrow">THE JOURNEY</p><h2>Every remarkable story deserves its stage.</h2><div className="steps"><article><span>01</span><h3>Choose your category</h3><p>Find the space that best celebrates your talent, service or impact.</p></article><article><span>02</span><h3>Register your story</h3><p>Create your nominee profile in a few thoughtful steps.</p></article><article><span>03</span><h3>Join the celebration</h3><p>Stay active and be part of the awards experience.</p></article></div></section><section className="section highlight"><div><p className="eyebrow">AWARD CATEGORIES</p><h2>Made for the people moving our community forward.</h2><a className="link gold" href="#/categories">See every category <ArrowRight size={16}/></a></div><div className="category-list">{categories.map((c, i) => <article key={c.id}><span>0{i + 1}</span><h3>{c.name}</h3><p>{c.description || "A category celebrating excellence in our community."}</p></article>)}</div></section><section className="cta"><Crown/><h2>Your name belongs in the room.</h2><a className="button" href="#/register">Start your nomination <ArrowRight size={17}/></a></section></main><Footer/></> }

//for video background
// function Home() { const [categories, setCategories] = useState<Category[]>([]); useEffect(() => { awardsApi.categories().then(x => setCategories(x.categories.slice(0, 3))).catch(() => {}); }, []); return <><Header/><main><section className="hero"><div className="hero-video"><video autoPlay muted loop playsInline src={BRAND.videoPath}/></div><div className="hero-copy"><p className="eyebrow">ODOBEN'S NIGHT OF DISTINCTION</p><h1>Own your <i>moment.</i></h1><p>{BRAND.slogan} Step forward, share your story and let the community celebrate what you bring to Odoben.</p><div className="actions"><a className="button" href="#/register">Become a nominee <ArrowRight size={17}/></a><a className="link" href="#/categories">Explore categories</a></div></div><div className="hero-mark"><Sparkles/><span>YES<br/>2026</span></div></section><section className="section" id="how-it-works"><p className="eyebrow">THE JOURNEY</p><h2>Every remarkable story deserves its stage.</h2><div className="steps"><article><span>01</span><h3>Choose your category</h3><p>Find the space that best celebrates your talent, service or impact.</p></article><article><span>02</span><h3>Register your story</h3><p>Create your nominee profile in a few thoughtful steps.</p></article><article><span>03</span><h3>Join the celebration</h3><p>Stay active and be part of the awards experience.</p></article></div></section><section className="section highlight"><div><p className="eyebrow">AWARD CATEGORIES</p><h2>Made for the people moving our community forward.</h2><a className="link gold" href="#/categories">See every category <ArrowRight size={16}/></a></div><div className="category-list">{categories.map((c, i) => <article key={c.id}><span>0{i + 1}</span><h3>{c.name}</h3><p>{c.description || "A category celebrating excellence in our community."}</p></article>)}</div></section><section className="cta"><Crown/><h2>Your name belongs in the room.</h2><a className="button" href="#/register">Start your nomination <ArrowRight size={17}/></a></section></main><Footer/></> }

function Categories() { const [query, setQuery] = useState(""); const [items, setItems] = useState<Category[]>([]); const [state, setState] = useState<"loading" | "error" | "done">("loading"); const load = () => { setState("loading"); awardsApi.categories(query).then(x => { setItems(x.categories); setState("done"); }).catch(() => setState("error")); }; useEffect(load, [query]); return <><Header/><main className="page"><p className="eyebrow">FIND YOUR STAGE</p><h1>A category for every kind of brilliance.</h1><div className="search"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search categories"/></div>{state === "loading" ? <Loading label="Finding categories"/> : state === "error" ? <ErrorState message="We couldn't load the categories." retry={load}/> : items.length ? <div className="category-grid">{items.map((c, i) => <article key={c.id} className="category"><span>0{i + 1}</span><h2>{c.name}</h2><p>{c.description || "Celebrating outstanding contribution, drive and excellence."}</p><a href="#/register">Nominate yourself <ArrowRight size={16}/></a></article>)}</div> : <Empty label="No categories match your search."/>}</main><Footer/></> }

function Register() { const [step, setStep] = useState(1); const [categories, setCategories] = useState<Category[]>([]); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [created, setCreated] = useState<User | null>(null); const [form, setForm] = useState<CreateUser>({ firstName: "", lastName: "", nickName: "", phoneNumber: "", gender: "MALE", password: "", role: "NOMINEE", category: "", interest: "COMMITTED" });
 useEffect(() => { awardsApi.categories().then(x => setCategories(x.categories)).catch(() => setError("Categories are unavailable. Please try again shortly.")); }, []); const valid = step === 1 ? form.firstName && form.lastName && /^\d{10}$/.test(form.phoneNumber) && form.password.length >= 8 : step === 2 ? form.category : true; const submit = async () => { setSaving(true); setError(""); try { const user = await awardsApi.createUser({ ...form, firstName: formatName(form.firstName), lastName: formatName(form.lastName), nickName: form.nickName ? formatName(form.nickName) : "" }); setCreated(user); setStep(4); } catch (e) { setError(e instanceof Error ? e.message : "Unable to register."); } finally { setSaving(false); } }; const change = <K extends keyof typeof form>(k: K, v: typeof form[K]) => setForm(x => ({ ...x, [k]: (k === "firstName" || k === "lastName" || k === "nickName") ? formatName(String(v)) : v }));
 if (created) return <><Header/><main className="form-page"><div className="success-panel"><Check/><p className="eyebrow">YOU'RE ON THE LIST</p><h1>Welcome, {created.firstName}.</h1><p>Your nominee account is ready. Add a flyer-ready photo now, or return whenever you are ready.</p><a className="button" href="#/dashboard">Open my profile <ArrowRight size={17}/></a></div></main><Footer/></>;
 return <><Header/><main className="form-page"><div className="form-intro"><p className="eyebrow">BECOME A NOMINEE</p><h1>This is where your story begins.</h1><p>Complete your profile with care. It only takes a few minutes.</p></div><div className="progress">{["Your details", "Your category", "Your commitment"].map((x, i) => <div key={x} className={step >= i + 1 ? "active" : ""}><span>{i + 1}</span>{x}</div>)}</div><div className="form-card">{error && <Notice text={error}/>} {step === 1 && <><h2>Tell us about you.</h2><div className="form-grid"><Field label="First name" value={form.firstName} onChange={v => change("firstName", v)}/><Field label="Last name" value={form.lastName} onChange={v => change("lastName", v)}/><Field label="Nickname (optional)" hint="This will be shown as your nominee name if you set one" value={form.nickName ?? ""} onChange={v => change("nickName", v)}/><Field label="Whatsapp number" hint="10 digits, e.g. 0240000000" value={form.phoneNumber} onChange={v => change("phoneNumber", v)}/><label>Gender<select value={form.gender} onChange={e => change("gender", e.target.value as Gender)}><option value="MALE">Male</option><option value="FEMALE">Female</option></select></label><Field label="Create a password" type="password" hint="At least 8 characters" value={form.password} onChange={v => change("password", v)}/></div></>}{step === 2 && <><h2>Choose your stage.</h2><p className="muted">Search and select the one category that best represents you.</p><CategoryPicker categories={categories} value={form.category ?? ""} onChange={v => change("category", v)}/></>}{step === 3 && <><h2>How ready are you?</h2><p className="muted">Tell us how you plan to show up for the awards experience.</p><label>Commitment<select value={form.interest ?? "COMMITTED"} onChange={e => change("interest", e.target.value as Interest)}><option value="EXPLORING">Exploring the opportunity</option><option value="COMMITTED">Committed to participate</option><option value="HIGHLY_COMMITTED">Highly committed</option><option value="FULLY_COMMITTED">Fully committed</option></select></label></>}<div className="form-actions">{step > 1 && <button className="text-btn" onClick={() => setStep(step - 1)}><ChevronLeft size={17}/> Back</button>}<button className="button" disabled={!valid || saving} onClick={() => step < 3 ? setStep(step + 1) : submit()}>{saving ? "Creating account…" : step === 3 ? "Create nominee account" : <>Continue <ChevronRight size={17}/></>}</button></div></div></main><Footer/></> }
function CategoryPicker({ categories, value, onChange }: { categories: Category[]; value: string; onChange: (value: string) => void }) { const [query, setQuery] = useState(""); const [open, setOpen] = useState(false); const pickerRef = useRef<HTMLDivElement>(null); const inputRef = useRef<HTMLInputElement>(null); const visible = categories.filter(c => c.name.toLowerCase().includes(query.toLowerCase())); useEffect(() => { const closeOnOutsideClick = (event: MouseEvent) => { if (!pickerRef.current?.contains(event.target as Node)) setOpen(false); }; document.addEventListener("mousedown", closeOnOutsideClick); return () => document.removeEventListener("mousedown", closeOnOutsideClick); }, []); const openPicker = () => { setOpen(true); setTimeout(() => inputRef.current?.focus(), 0); }; return <div className="category-picker" ref={pickerRef}><label>Category<button type="button" className="category-trigger" aria-haspopup="listbox" aria-expanded={open} onClick={() => open ? setOpen(false) : openPicker()}>{value || "Select a category"}<ChevronRight size={17}/></button></label>{open && <div className="category-menu"><div className="category-search"><Search size={16}/><input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="Search categories" autoComplete="off"/></div><div className="category-options" role="listbox" aria-label="Award categories">{visible.length ? visible.map(c => <button type="button" role="option" aria-selected={value === c.name} className={value === c.name ? "selected" : ""} onClick={() => { onChange(c.name); setOpen(false); setQuery(""); }} key={c.id}><strong>{c.name}</strong>{c.description && <small>{c.description}</small>}<span>{value === c.name && <Check size={15}/>}</span></button>) : <p>No categories match "{query}".</p>}</div></div>}{value && <p className="small-note">Selected category: <strong>{value}</strong></p>}</div> }
function Field({ label, hint, type = "text", value, onChange }: { label: string; hint?: string; type?: string; value: string; onChange: (v: string) => void }) { const [visible, setVisible] = useState(false); const secret = type === "password"; return <label>{label}<span className={secret ? "input-with-action" : undefined}><input type={secret && visible ? "text" : type} value={value} onChange={e => onChange(e.target.value)}/>{secret && <button type="button" className="input-action" aria-label={visible ? "Hide password" : "Show password"} title={visible ? "Hide password" : "Show password"} onClick={() => setVisible(current => !current)}>{visible ? <EyeOff size={16}/> : <Eye size={16}/>}</button>}</span>{hint && <small>{hint}</small>}</label>; }
function Login() { const [phone, setPhone] = useState(""); const [password, setPassword] = useState(""); const [error, setError] = useState(""); const [loading, setLoading] = useState(false); const submit = async (e: React.FormEvent) => { e.preventDefault(); setLoading(true); setError(""); try { const data = await awardsApi.login(phone, password); session.set(data); location.hash = data.user.role === "NOMINEE" ? "/dashboard" : "/admin"; } catch (err) { setError(err instanceof Error ? err.message : "Unable to sign in."); } finally { setLoading(false); } }; return <><Header/><main className="auth"><form className="auth-card" onSubmit={submit}><p className="eyebrow">WELCOME BACK</p><h1>Enter the ceremony.</h1>{error && <Notice text={error}/>}<Field label="Phone number" value={phone} onChange={setPhone}/><Field label="Password" type="password" value={password} onChange={setPassword}/><button className="button" disabled={loading}>{loading ? "Signing in…" : "Sign in"}<ArrowRight size={17}/></button><a className="link" href="#/forgot-password">Forgot your password?</a><p className="muted">New here? <a href="#/register">Become a nominee</a></p></form></main><Footer/></> }
function Forgot() { return <><Header/><main className="auth"><div className="auth-card"><Heart className="big-icon"/><p className="eyebrow">WE'RE HERE TO HELP</p><h1>Reset your password.</h1><p>Our award administrators will securely help you regain access over WhatsApp.</p><button className="button" onClick={() => openResetWhatsApp()}>Message an administrator <ArrowRight size={17}/></button></div></main><Footer/></> }
function Dashboard() { const active = session.get(); const [user, setUser] = useState<User | null>(null); const [edit, setEdit] = useState(false); const [error, setError] = useState(""); const [saving, setSaving] = useState(false); const [photoUploading, setPhotoUploading] = useState(false); const [photoProgress, setPhotoProgress] = useState(0); const load = async () => { if (!active) return; try { setUser(await awardsApi.user(active.user.id)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to load profile."); } }; useEffect(() => { void load(); }, []); const save = async (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); if (!user) return; setSaving(true); try { const f = new FormData(e.currentTarget); const fresh = await awardsApi.updateUser(user.id, { firstName: String(f.get("firstName")), lastName: String(f.get("lastName")), nickName: String(f.get("nickName")), gender: f.get("gender") as Gender }); setUser(fresh); setEdit(false); } catch (e) { setError(e instanceof Error ? e.message : "Could not save changes."); } finally { setSaving(false); } }; if (!active) { location.hash = "/login"; return null; } if (!user) return <main className="dash"><Loading label="Loading your profile"/>{error && <ErrorState message={error} retry={() => void load()}/>}</main>; const pick = async (file: File) => { setPhotoUploading(true); setPhotoProgress(0); try { setUser(await uploadProfilePhotoWithProgress(user.id, file, setPhotoProgress)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to upload photo."); } finally { setPhotoUploading(false); setPhotoProgress(0); } }; return <main className="dash"><DashboardHeader title={`Good to see you, ${user.firstName}.`}/>{error && <Notice text={error}/>}<section className="dashboard-grid"><div className="profile-main"><PhotoUpload user={user} onPick={pick} pending={photoUploading} uploadProgress={photoProgress}/><div className="panel"><div className="panel-title"><div><p className="eyebrow">YOUR DETAILS</p><h2>Personal profile</h2></div><button className="text-btn" onClick={() => setEdit(!edit)}>{edit ? "Cancel" : "Edit profile"}</button></div>{edit ? <form className="form-grid" onSubmit={save}><label>First name<input name="firstName" defaultValue={user.firstName}/></label><label>Last name<input name="lastName" defaultValue={user.lastName}/></label><label>Nickname<input name="nickName" defaultValue={user.nickName ?? ""}/></label><label>Gender<select name="gender" defaultValue={user.gender}><option value="male">Male</option><option value="female">Female</option></select></label><button className="button" disabled={saving}>Save changes</button></form> : <dl><div><dt>Full name</dt><dd>{user.firstName} {user.lastName}</dd></div><div><dt>Nickname</dt><dd>{user.nickName || "—"}</dd></div><div><dt>Whatsapp number</dt><dd>{user.phoneNumber}</dd></div><div><dt>Participation</dt><dd><span className={user.isActive ? "pill green" : "pill"}>{user.isActive ? "Active" : "Inactive"}</span></dd></div></dl>}</div></div><aside className="side-stack"><div className="panel"><ShieldCheck className="gold-icon"/><h3>Stay active</h3><p>Your active status shows your continued interest in the programme. Contact an administrator if you need help.</p><button className="link" onClick={() => confirm("Changing activity status is not supported by the current API. Inactivity may be considered a loss of interest and could result in removal from programme activities and the WhatsApp group.")}>About inactivity</button></div><div className="panel"><h3>Need account help?</h3><p>Request a password reset directly from an awards administrator.</p><button className="button mini" onClick={() => openResetWhatsApp(`${user.firstName} ${user.lastName}`)}>Contact on WhatsApp</button></div></aside></section></main> }
function AdminUserDetailsContent({ user, onUpdated, onClose }: { user: User; onUpdated: (user: User) => void; onClose: () => void }) {
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const isNominee = user.role === "NOMINEE";
  const upload = async (file: File) => { setUploading(true); setError(""); try { onUpdated(await awardsApi.uploadPhoto(user.id, file)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to update profile image."); } finally { setUploading(false); } };
  return <section className="panel admin-user-details">
    <div className="panel-title"><div><p className="eyebrow">USER DETAILS</p><h2>{user.firstName} {user.lastName}</h2></div><button className="text-btn" type="button" onClick={onClose}>Close</button></div>
    {error && <Notice text={error}/>}
    {isNominee && <PhotoUpload user={user} pending={uploading} isAdmin onPick={upload} onLimitHelp={() => setError("This user has used all profile image changes allowed by the programme.")}/>}
    <dl>
      <div><dt>Phone number</dt><dd>{user.phoneNumber}</dd></div>
      <div><dt>Gender</dt><dd>{user.gender.toLowerCase()}</dd></div>
      <div><dt>Role</dt><dd>{prettyRole(user.role)}</dd></div>
      {isNominee && <div><dt>Category</dt><dd>{user.category || "—"}</dd></div>}
      {isNominee && user.nomineeCode && <div><dt>Nominee code</dt><dd>{user.nomineeCode}</dd></div>}
      {isNominee && <div><dt>Commitment</dt><dd>{user.interest ? user.interest.replace(/_/g, " ").toLowerCase() : "—"}</dd></div>}
      <div><dt>Joined</dt><dd>{new Date(user.createdAt).toLocaleDateString()}</dd></div>
    </dl>
  </section>;
}
function AdminSelfProfile() {
  const active = session.get();
  const [user, setUser] = useState<User | null>(null);
  const [error, setError] = useState("");
  const [resetting, setResetting] = useState(false);
  const load = async () => { if (!active) return; try { setUser(await awardsApi.user(active.user.id)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to load your profile."); } };
  useEffect(() => { void load(); }, []);
  if (!active) return null;
  if (!user) return <div className="panel">{error ? <ErrorState message={error} retry={() => void load()}/> : <Loading label="Loading your profile"/>}</div>;
  return <section className="dashboard-grid admin-self-profile"><div className="profile-main"><PersonalInfo user={user} onUpdated={setUser}/>{resetting ? <ResetUserPassword user={user} onDone={() => setResetting(false)} onCancel={() => setResetting(false)}/> : <div className="panel"><div className="panel-title"><div><p className="eyebrow">SECURITY</p><h2>Password</h2></div></div><button type="button" className="button mini" onClick={() => setResetting(true)}><KeyRound size={15}/> Reset my password</button></div>}</div></section>;
}

function AdminEditProfile({ user, onUpdated }: { user: User; onUpdated: (user: User) => void }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryValue, setCategoryValue] = useState(user.category);
  const [nomineeCodeValue, setNomineeCodeValue] = useState(user.nomineeCode ?? "");
  const isNominee = user.role === "NOMINEE";

  useEffect(() => { if (!isNominee) return; awardsApi.categories().then(x => setCategories(x.categories)).catch(() => {}); }, [isNominee]);

  const save = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      onUpdated(await awardsApi.updateUser(user.id, {
        firstName: String(form.get("firstName")),
        lastName: String(form.get("lastName")),
        nickName: String(form.get("nickName")),
        gender: form.get("gender") as Gender,
        ...(isNominee ? { category: categoryValue, nomineeCode: nomineeCodeValue.trim() || null } : {}),
      }));
      setEditing(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to save changes.");
    } finally {
      setSaving(false);
    }
  };

  if (!editing) return <button type="button" className="button mini" onClick={() => setEditing(true)}><Edit3 size={15}/> Edit profile</button>;

  return <form className="form-grid" onSubmit={save}>
    {error && <Notice text={error}/>}
    <label>First name<input name="firstName" defaultValue={user.firstName}/></label>
    <label>Last name<input name="lastName" defaultValue={user.lastName}/></label>
    <label>Nickname<input name="nickName" defaultValue={user.nickName ?? ""}/></label>
    <label>Gender<select name="gender" defaultValue={user.gender}><option value="MALE">Male</option><option value="FEMALE">Female</option></select></label>
    {isNominee && <CategoryPicker categories={categories} value={categoryValue} onChange={setCategoryValue}/>}
    {isNominee && <label>Nominee code<input value={nomineeCodeValue} onChange={e => setNomineeCodeValue(e.target.value)} placeholder="e.g. OY-2026-014"/></label>}
    <div className="form-actions">
      <button className="button" disabled={saving}>{saving ? "Saving…" : "Save changes"}</button>
      <button type="button" className="text-btn" onClick={() => setEditing(false)}><X size={16}/> Cancel</button>
    </div>
  </form>;
}

function AdminCreateUser({ canCreateAdmins, categories, onCreated }: { canCreateAdmins: boolean; categories: Category[]; onCreated: () => void }) { const [form, setForm] = useState<CreateUser>({ firstName: "", lastName: "", nickName: "", phoneNumber: "", gender: "MALE", password: "", role: "NOMINEE", category: "", interest: "COMMITTED" }); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [success, setSuccess] = useState(""); const change = <K extends keyof CreateUser>(key: K, value: CreateUser[K]) => setForm(current => ({ ...current, [key]: (key === "firstName" || key === "lastName" || key === "nickName") ? formatName(String(value)) : value })); const valid = form.firstName.trim() && form.lastName.trim() && /^\d{10}$/.test(form.phoneNumber) && form.password.length >= 8 && (form.role !== "NOMINEE" || form.category); const submit = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); if (!valid) return; setSaving(true); setError(""); setSuccess(""); try { const normalizedFirstName = formatName(form.firstName); const normalizedLastName = formatName(form.lastName); const normalizedNickName = form.nickName ? formatName(form.nickName) : ""; const payload = form.role === "NOMINEE" ? { ...form, firstName: normalizedFirstName, lastName: normalizedLastName, nickName: normalizedNickName } : { ...form, firstName: normalizedFirstName, lastName: normalizedLastName, nickName: normalizedNickName, category: undefined, interest: undefined }; await awardsApi.createUser(payload); setForm({ firstName: "", lastName: "", nickName: "", phoneNumber: "", gender: "MALE", password: "", role: "NOMINEE", category: "", interest: "COMMITTED" }); setSuccess("Account created successfully."); onCreated(); } catch (e) { setError(e instanceof Error ? e.message : "Unable to create user."); } finally { setSaving(false); } }; return <section className="panel admin-form"><div className="panel-title"><div><p className="eyebrow">ACCOUNT MANAGEMENT</p><h2>Create an account</h2></div><KeyRound className="gold-icon"/></div>{error && <Notice text={error}/>} {success && <Notice text={success} kind="success"/>}<form className="form-grid" onSubmit={submit}><Field label="First name" value={form.firstName} onChange={value => change("firstName", value)}/><Field label="Last name" value={form.lastName} onChange={value => change("lastName", value)}/><Field label="Nickname (optional)" hint="This will be shown as your nominee name if you set one" value={form.nickName ?? ""} onChange={value => change("nickName", value)}/><Field label="Phone number" hint="10 digits, e.g. 0240000000" value={form.phoneNumber} onChange={value => change("phoneNumber", value)}/><label>Gender<select value={form.gender} onChange={event => change("gender", event.target.value as Gender)}><option value="MALE">Male</option><option value="FEMALE">Female</option></select></label><Field label="Temporary password" type="password" hint="At least 8 characters" value={form.password} onChange={value => change("password", value)}/><label>Account type<select value={form.role} onChange={event => change("role", event.target.value as CreateUser["role"])}><option value="NOMINEE">Nominee</option>{canCreateAdmins && <option value="ADMIN">Admin</option>}</select></label>{form.role === "NOMINEE" && <><CategoryPicker categories={categories} value={form.category ?? ""} onChange={value => change("category", value)}/><label>Commitment<select value={form.interest} onChange={event => change("interest", event.target.value as Interest)}><option value="EXPLORING">Exploring</option><option value="COMMITTED">Committed</option><option value="HIGHLY_COMMITTED">Highly committed</option><option value="FULLY_COMMITTED">Fully committed</option></select></label></>}<button className="button" disabled={!valid || saving}>{saving ? "Creating…" : "Create account"}<ArrowRight size={17}/></button></form></section> }
function ResetUserPassword({ user, onDone, onCancel }: { user: User; onDone: () => void; onCancel: () => void }) { const [password, setPassword] = useState(""); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const submit = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); if (password.length < 8) return; setSaving(true); setError(""); try { await awardsApi.updateUser(user.id, { password }); onDone(); } catch (e) { setError(e instanceof Error ? e.message : "Unable to reset password."); } finally { setSaving(false); } }; return <section className="panel reset-panel"><div className="panel-title"><div><p className="eyebrow">PASSWORD RESET</p><h2>{user.firstName} {user.lastName}</h2></div><button className="text-btn" type="button" onClick={onCancel}>Cancel</button></div>{error && <Notice text={error}/>}<form className="form-actions" onSubmit={submit}><Field label="New temporary password" type="password" hint="At least 8 characters" value={password} onChange={setPassword}/><button className="button" disabled={password.length < 8 || saving}>{saving ? "Resetting…" : "Reset password"}<KeyRound size={17}/></button></form></section> }
function AdminDirectory() { const active = session.get(); const [users, setUsers] = useState<User[]>([]); const [categories, setCategories] = useState<Category[]>([]); const [query, setQuery] = useState(""); const [gender, setGender] = useState(""); const [status, setStatus] = useState(""); const [roleFilter, setRoleFilter] = useState(""); const [error, setError] = useState(""); const [success, setSuccess] = useState(""); const [resetUser, setResetUser] = useState<User | null>(null); const [deletingId, setDeletingId] = useState(""); const canCreateAdmins = active?.user.role === "SUPER_ADMIN"; const load = () => { const params = new URLSearchParams(); if (roleFilter) params.set("role", roleFilter); if (gender) params.set("gender", gender); if (status) params.set("isActive", status); awardsApi.users(params.toString()).then(x => setUsers(x.users)).catch(e => setError(e instanceof Error ? e.message : "Unable to load users.")); }; useEffect(load, [roleFilter, gender, status]); useEffect(() => { awardsApi.categories().then(x => setCategories(x.categories)).catch(e => setError(e instanceof Error ? e.message : "Unable to load categories.")); }, []); const filtered = useMemo(() => users.filter(user => `${user.firstName} ${user.lastName} ${user.phoneNumber} ${user.nickName || ""} ${user.category} ${user.role}`.toLowerCase().includes(query.toLowerCase())), [users, query]); const canReset = (user: User) => canCreateAdmins || user.role !== "SUPER_ADMIN"; const canDelete = (user: User) => user.id !== active?.user.id && (canCreateAdmins || user.role !== "SUPER_ADMIN"); const deleteUser = async (user: User) => { if (!canDelete(user) || !confirm(`Delete ${user.firstName} ${user.lastName}'s account? This cannot be undone.`)) return; setDeletingId(user.id); setError(""); setSuccess(""); try { await awardsApi.deleteUsers([user.id]); setSuccess("Account deleted successfully."); await load(); } catch (e) { setError(e instanceof Error ? e.message : "Unable to delete user."); } finally { setDeletingId(""); } }; if (!active || active.user.role === "NOMINEE") { location.hash = "/login"; return null; } return <main className="dash"><DashboardHeader title="Awards administration"/>{error && <Notice text={error}/>} {success && <div className="notice success" role="status">{success}</div>}<AdminSelfProfile/><div className="stat-row"><Stat icon={<UsersRound/>} label="Users" value={users.length}/><Stat icon={<ShieldCheck/>} label="Active" value={users.filter(user => user.isActive).length}/><Stat icon={<Crown/>} label="Your access" value={prettyRole(active.user.role)}/></div><AdminCreateUser canCreateAdmins={canCreateAdmins} categories={categories} onCreated={() => { void load(); }}/>{resetUser && <ResetUserPassword user={resetUser} onDone={() => { setResetUser(null); setSuccess("Password reset successfully."); }} onCancel={() => setResetUser(null)}/>}<section className="panel"><div className="panel-title"><div><p className="eyebrow">DIRECTORY</p><h2>Users</h2></div></div><div className="filters"><div className="search"><Search size={17}/><input placeholder="Search name, phone, nickname or category" value={query} onChange={event => setQuery(event.target.value)}/></div><select value={roleFilter} onChange={event => setRoleFilter(event.target.value)}><option value="">All account types</option><option value="NOMINEE">Nominees</option><option value="ADMIN">Admins</option>{canCreateAdmins && <option value="SUPER_ADMIN">Super admins</option>}</select><select value={gender} onChange={event => setGender(event.target.value)}><option value="">All genders</option><option value="MALE">Male</option><option value="FEMALE">Female</option></select><select value={status} onChange={event => setStatus(event.target.value)}><option value="">All statuses</option><option value="true">Active</option><option value="false">Inactive</option></select></div>{filtered.length ? <div className="table-wrap"><table><thead><tr><th>User</th><th>Role</th><th>Category</th><th>Nominee Code</th><th>Phone</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>{filtered.map(user => <tr key={user.id} data-user-id={user.id}><td><strong>{user.firstName} {user.lastName}</strong><small>{user.nickName || "No nickname"}</small></td><td>{prettyRole(user.role)}</td><td>{user.category || "—"}</td><td>{user.nomineeCode || "—"}</td><td>{user.phoneNumber}</td><td><span className={user.isActive ? "pill green" : "pill"}>{user.isActive ? "Active" : "Inactive"}</span></td><td>{new Date(user.createdAt).toLocaleDateString()}</td><td>{(canReset(user) || canDelete(user)) && <>{canReset(user) && <button className="text-btn" onClick={() => setResetUser(user)}><KeyRound size={15}/> Reset password</button>}{canDelete(user) && <button className="text-btn danger" disabled={deletingId === user.id} onClick={() => void deleteUser(user)}>{deletingId === user.id ? "Deleting…" : "Delete account"}</button>}</>}</td></tr>)}</tbody></table></div> : <Empty label="No users match these filters."/>}</section></main> }
function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) { return <div className="stat"><span>{icon}</span><p>{label}</p><h2>{value}</h2></div>; }
function DashboardEnhanced() { const active = session.get(); const [user, setUser] = useState<User | null>(null); const [error, setError] = useState(""); const [changingStatus, setChangingStatus] = useState(false); const [photoUploading, setPhotoUploading] = useState(false); const [photoProgress, setPhotoProgress] = useState(0); const load = async () => { if (!active) return; try { setUser(await awardsApi.user(active.user.id)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to load profile."); } }; useEffect(() => { void load(); }, []); if (!active) { location.hash = "/login"; return null; } if (!user) return <main className="dash"><Loading label="Loading your profile"/>{error && <ErrorState message={error} retry={() => void load()}/>}</main>; const pick = async (file: File) => { setPhotoUploading(true); setPhotoProgress(0); try { setUser(await uploadProfilePhotoWithProgress(user.id, file, setPhotoProgress)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to upload photo."); } finally { setPhotoUploading(false); setPhotoProgress(0); } }; const toggleStatus = async () => { if (user.status === "ACTIVE" && !confirm("Become inactive? Inactivity may be treated as loss of interest and could result in removal from the programme, related activities and the WhatsApp group.")) return; setChangingStatus(true); try { setUser(await awardsApi.toggleStatus(user.id)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to update your status."); } finally { setChangingStatus(false); } }; return <main className="dash"><DashboardHeader title={`Good to see you, ${user.firstName}.`}/>{error && <Notice text={error}/>}<section className="dashboard-grid"><div className="profile-main"><PhotoUpload user={user} pending={photoUploading} uploadProgress={photoProgress} onPick={pick} onLimitHelp={() => openPhotoChangeWhatsApp(`${user.firstName} ${user.lastName}`)}/><div className="panel"><p className="eyebrow">YOUR AWARDS PROFILE</p><h2>{user.category}</h2><p>Your commitment: {user.interest.replace(/_/g, " ").toLowerCase()}.</p><dl><div><dt>Full name</dt><dd>{user.firstName} {user.lastName}</dd></div><div><dt>Whatsapp number</dt><dd>{user.phoneNumber}</dd></div><div><dt>Nickname</dt><dd>{user.nickName || "—"}</dd></div></dl></div></div><aside className="side-stack"><div className="panel"><ShieldCheck className="gold-icon"/><h3>Participation status</h3><p>You are currently <span className={user.status === "ACTIVE" ? "pill green" : "pill"}>{user.status.toLowerCase()}</span>.</p><button className="button mini" disabled={changingStatus} onClick={() => void toggleStatus()}>{changingStatus ? "Updating…" : user.status === "ACTIVE" ? "Become inactive" : "Become active"}</button></div><div className="panel"><h3>Need account help?</h3><p>Request a password reset directly from an awards administrator.</p><button className="button mini" onClick={() => openResetWhatsApp(`${user.firstName} ${user.lastName}`)}>Contact on WhatsApp</button></div></aside></section></main> }

// function PersonalInfo({ user, onUpdated }: { user: User; onUpdated: (user: User) => void }) { const [editing, setEditing] = useState(false); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const save = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); setSaving(true); setError(""); const form = new FormData(event.currentTarget); try { const firstName = formatName(String(form.get("firstName"))); const lastName = formatName(String(form.get("lastName"))); const nickName = formatName(String(form.get("nickName"))); onUpdated(await awardsApi.updateUser(user.id, { firstName, lastName, nickName, gender: form.get("gender") as Gender })); setEditing(false); } catch (e) { setError(e instanceof Error ? e.message : "Unable to save your personal information."); } finally { setSaving(false); } }; return <div className="panel"><div className="panel-title"><div><p className="eyebrow">YOUR DETAILS</p><h2>Personal information</h2></div><button className="text-btn" onClick={() => setEditing(x => !x)}>{editing ? "Cancel" : "Edit profile"}</button></div>{error && <Notice text={error}/>}{editing ? <form className="form-grid" onSubmit={save}><label>First name<input name="firstName" defaultValue={user.firstName}/></label><label>Last name<input name="lastName" defaultValue={user.lastName}/></label><label>Nickname<input name="nickName" defaultValue={user.nickName ?? ""}/></label><label>Gender<select name="gender" defaultValue={user.gender}><option value="MALE">Male</option><option value="FEMALE">Female</option></select></label><button className="button" disabled={saving}>{saving ? "Saving…" : "Save changes"}</button></form> : <dl><div><dt>Full name</dt><dd>{user.firstName} {user.lastName}</dd></div><div><dt>Whatsapp number</dt><dd>{user.phoneNumber}</dd></div><div><dt>Nickname</dt><dd>{user.nickName || "—"}</dd></div><div><dt>Category</dt><dd>{user.category}</dd></div><div><dt>Commitment</dt><dd>{user.interest.replace(/_/g, " ").toLowerCase()}</dd></div></dl>}</div> }

function PersonalInfo({ user, onUpdated }: { user: User; onUpdated: (user: User) => void }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [editingCategory, setEditingCategory] = useState(false);
  const [categoryValue, setCategoryValue] = useState(user.category);
  const [categorySaving, setCategorySaving] = useState(false);
  const [categoryError, setCategoryError] = useState("");
  const isNominee = user.role === "NOMINEE";

  useEffect(() => { if (!isNominee) return; awardsApi.categories().then(x => setCategories(x.categories)).catch(() => {}); }, [isNominee]);

  const save = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); setSaving(true); setError(""); const form = new FormData(event.currentTarget); try { onUpdated(await awardsApi.updateUser(user.id, { firstName: String(form.get("firstName")), lastName: String(form.get("lastName")), nickName: String(form.get("nickName")), gender: form.get("gender") as Gender })); setEditing(false); } catch (e) { setError(e instanceof Error ? e.message : "Unable to save your personal information."); } finally { setSaving(false); } };

  const saveCategory = async () => {
    if (!categoryValue || categoryValue === user.category) { setEditingCategory(false); return; }
    setCategorySaving(true);
    setCategoryError("");
    try {
      onUpdated(await awardsApi.updateUser(user.id, { category: categoryValue }));
      setEditingCategory(false);
    } catch (e) {
      setCategoryError(e instanceof Error ? e.message : "Unable to update your category.");
    } finally {
      setCategorySaving(false);
    }
  };

  return <div className="panel"><div className="panel-title"><div><p className="eyebrow">YOUR DETAILS</p><h2>Personal information</h2></div><button className="text-btn" onClick={() => setEditing(x => !x)}>{editing ? "Cancel" : "Edit profile"}</button></div>{error && <Notice text={error}/>}{editing ? <form className="form-grid" onSubmit={save}><label>First name<input name="firstName" defaultValue={user.firstName}/></label><label>Last name<input name="lastName" defaultValue={user.lastName}/></label><label>Nickname<input name="nickName" defaultValue={user.nickName ?? ""}/></label><label>Gender<select name="gender" defaultValue={user.gender}><option value="MALE">Male</option><option value="FEMALE">Female</option></select></label>{isNominee && user.nomineeCode && <label>Nominee code<input value={user.nomineeCode} disabled/></label>}<button className="button" disabled={saving}>{saving ? "Saving…" : "Save changes"}</button></form> : <dl><div><dt>Full name</dt><dd>{user.firstName} {user.lastName}</dd></div><div><dt>Whatsapp number</dt><dd>{user.phoneNumber}</dd></div><div><dt>Nickname</dt><dd>{user.nickName || "—"}</dd></div>{isNominee && <div><dt>Category</dt><dd style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>{user.category}{!editingCategory && <button type="button" className="text-btn" onClick={() => { setCategoryValue(user.category); setCategoryError(""); setEditingCategory(true); }}><Edit3 size={14}/> Change</button>}</dd>{editingCategory && <div style={{ marginTop: 12 }}>{categoryError && <Notice text={categoryError}/>}<CategoryPicker categories={categories} value={categoryValue} onChange={setCategoryValue}/><div className="form-actions" style={{ marginTop: 10 }}><button className="button mini" disabled={categorySaving || !categoryValue || categoryValue === user.category} onClick={() => void saveCategory()}>{categorySaving ? "Saving…" : "Save category"}</button><button type="button" className="text-btn" onClick={() => setEditingCategory(false)}>Cancel</button></div></div>}</div>}{isNominee && user.nomineeCode && <div><dt>Nominee code</dt><dd>{user.nomineeCode}</dd></div>}{isNominee && <div><dt>Commitment</dt><dd>{user.interest.replace(/_/g, " ").toLowerCase()}</dd></div>}</dl>}</div>;
}

function DashboardComplete() {
  const active = session.get();
  const [user, setUser] = useState<User | null>(null);
  const [error, setError] = useState("");
  const [changingStatus, setChangingStatus] = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoProgress, setPhotoProgress] = useState(0);

  const load = async () => {
    if (!active) return;

    try {
      setUser(await awardsApi.user(active.user.id));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to load profile.");
    }
  };

  useEffect(() => {
    void load();
  }, []);

  if (!active) {
    location.hash = "/login";
    return null;
  }

  if (!user) {
    return (
      <main className="dash">
        <Loading label="Loading your profile" />
        {error && <ErrorState message={error} retry={() => void load()} />}
      </main>
    );
  }

  const pick = async (file: File) => {
    setPhotoUploading(true);
    setPhotoProgress(0);

    try {
      setUser(await uploadProfilePhotoWithProgress(user.id, file, setPhotoProgress));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to upload photo.");
    } finally {
      setPhotoUploading(false);
      setPhotoProgress(0);
    }
  };

  const toggleStatus = async () => {
    if (
      user.status === "ACTIVE" &&
      !confirm(
        "Become inactive? Inactivity may be treated as loss of interest and could result in removal from the programme, related activities and the WhatsApp group."
      )
    ) {
      return;
    }

    setChangingStatus(true);

    try {
      setUser(await awardsApi.toggleStatus(user.id));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to update your status.");
    } finally {
      setChangingStatus(false);
    }
  };

  return (
    <main className="dash">
      <DashboardHeader title={`Good to see you, ${user.firstName}.`} />

      <div style={{ marginTop: 16, marginBottom: 18 }}>
        <a
          href="https://chat.whatsapp.com/JgNpQrIq4CwCQoBrvv9UCl?s=cl&p=i&mlu=4&ilr=4"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "10px 18px",
            borderRadius: 8,
            background: "#25D366",
            color: "#fff",
            fontWeight: 700,
            textDecoration: "none",
            boxShadow: "0 4px 10px rgba(37,211,102,0.25)",
            marginBottom: 8,
          }}
        >
          Join Group
        </a>

        <div
          style={{
            color: "#7e8288",
            fontSize: 13,
            lineHeight: 1.5,
          }}
        >
          Join the nominees' WhatsApp group if you have not done that yet.
        </div>
      </div>

      {error && <Notice text={error} />}

      <section className="dashboard-grid">
        <div className="profile-main">
          <PhotoUpload
            user={user}
            pending={photoUploading}
            uploadProgress={photoProgress}
            onPick={pick}
            onLimitHelp={() => openPhotoChangeWhatsApp(`${user.firstName} ${user.lastName}`)}
          />

          <PersonalInfo user={user} onUpdated={setUser} />

          <FlyerCard
            user={user}
            contactNumbers={["0000-000-000", "0000-000-000"]}
            poweredBy="GENIUSERA"
            sponsors="PENDING"
          />
        </div>

        <aside className="side-stack">
          <div className="panel">
            <ShieldCheck className="gold-icon" />
            <h3>Participation status</h3>
            <p>
              You are currently{" "}
              <span className={user.status === "ACTIVE" ? "pill green" : "pill"}>
                {user.status.toLowerCase()}
              </span>
              .
            </p>
            <button
              className="button mini"
              disabled={changingStatus}
              onClick={() => void toggleStatus()}
            >
              {changingStatus
                ? "Updating…"
                : user.status === "ACTIVE"
                  ? "Become inactive"
                  : "Become active"}
            </button>
          </div>

          <div className="panel">
            <h3>Need account help?</h3>
            <p>Request a password reset directly from an awards administrator.</p>
            <button
              className="button mini"
              onClick={() => openResetWhatsApp(`${user.firstName} ${user.lastName}`)}
            >
              Contact on WhatsApp
            </button>
          </div>
        </aside>
      </section>
    </main>
  );
}

function AdminDetailsRoute() { const [user, setUser] = useState<User | null>(null); const [error, setError] = useState(""); const selected = new URLSearchParams(location.hash.split("?")[1] || "").get("user"); const close = () => { location.hash = "/admin"; }; useEffect(() => { setUser(null); setError(""); if (!selected) return; awardsApi.user(selected).then(u => setUser(u)).catch(e => setError(e instanceof Error ? e.message : "Unable to load user details.")); }, [selected]); if (!selected) return null; return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) close(); }}><section className="modal-card user-details-modal" role="dialog" aria-modal="true" aria-labelledby="user-details-title"><div className="modal-heading"><div><p className="eyebrow">USER DETAILS</p><h2 id="user-details-title">{user ? `${user.firstName} ${user.lastName}` : "Loading user"}</h2></div><button type="button" className="icon-button" aria-label="Close user details" title="Close" onClick={close}><X size={20}/></button></div>{error ? <Notice text={error}/> : !user ? <Loading label="Loading user details"/> : <AdminUserDetails user={user} onUpdated={setUser} onClose={close}/>}</section></div>; }

function AdminUserDetails({ user, onUpdated, onClose }: { user: User; onUpdated: (user: User) => void; onClose: () => void }) {
  const active = session.get();
  const isSuperAdmin = active?.user.role === "SUPER_ADMIN";
  const isSelf = active?.user.id === user.id;
  const canEdit = isSuperAdmin || isSelf || (active?.user.role === "ADMIN" && user.role === "NOMINEE");
  return <section className="admin-details-stack">
    <AdminUserDetailsContent user={user} onUpdated={onUpdated} onClose={onClose}/>
    {canEdit && <div className="admin-count-action"><AdminEditProfile user={user} onUpdated={onUpdated}/></div>}
    {user.role === "NOMINEE" && <div className="admin-count-action"><AdminResetImageCount user={user} onUpdated={onUpdated}/></div>}
  </section>;
}

function AdminShell({ modal = false }: { modal?: boolean }) { useEffect(() => { const openDetails = (event: MouseEvent) => { const cell = (event.target as HTMLElement).closest(".table-wrap tbody td:first-child"); if (!cell) return; const row = cell.closest("tr") as HTMLElement | null; const id = row?.dataset.userId; if (id) location.hash = `/admin?user=${encodeURIComponent(id)}`; }; document.addEventListener("click", openDetails); return () => document.removeEventListener("click", openDetails); }, []); return <div className={`admin-shell-content${modal ? " admin-shell-modal" : ""}`}><AdminDirectory/><AdminDetailsRoute/></div>; }
function CategoryManagementModal({ onClose }: { onClose: () => void }) { useEffect(() => { const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); }; document.addEventListener("keydown", closeOnEscape); return () => document.removeEventListener("keydown", closeOnEscape); }, [onClose]); return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="category-management-title"><div className="modal-heading"><div><p className="eyebrow">CATEGORY NAVIGATION</p><h2 id="category-management-title">Manage categories</h2></div><button type="button" className="icon-button" aria-label="Close category management" title="Close" onClick={onClose}><X size={20}/></button></div><CategoryManagementContent/></section></div>; }
function AccountManagementModal({ onClose }: { onClose: () => void }) { useEffect(() => { const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); }; document.addEventListener("keydown", closeOnEscape); return () => document.removeEventListener("keydown", closeOnEscape); }, [onClose]); return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><section className="modal-card account-modal" role="dialog" aria-modal="true" aria-labelledby="account-management-title"><div className="modal-heading"><div><p className="eyebrow">ACCOUNT MANAGEMENT</p><h2 id="account-management-title">Manage accounts</h2></div><button type="button" className="icon-button" aria-label="Close account management" title="Close" onClick={onClose}><X size={20}/></button></div><AdminShell modal/></section></div>; }
function Admin() { const [categoryModalOpen, setCategoryModalOpen] = useState(false); const [accountModalOpen, setAccountModalOpen] = useState(false); return <div className="admin-page"><AdminShell/><div className="admin-management-nav"><button type="button" className="button" onClick={() => setAccountModalOpen(true)}><UsersRound size={17}/> Manage accounts</button><button type="button" className="button" onClick={() => setCategoryModalOpen(true)}><Plus size={17}/> Manage categories</button></div>{accountModalOpen && <AccountManagementModal onClose={() => setAccountModalOpen(false)}/>} {categoryModalOpen && <CategoryManagementModal onClose={() => setCategoryModalOpen(false)}/>}</div>; }
export default function App() { const path = useHash(); if (path === "/categories") return <Categories/>; if (path === "/register") return <Register/>; if (path === "/login") return <Login/>; if (path === "/forgot-password") return <Forgot/>; if (path === "/dashboard") return <DashboardComplete/>; if (path.startsWith("/admin")) return <Admin/>; return <Home/>; }
